package com.buildstart.util;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import javax.imageio.ImageIO;

public class GenerateTestSlips {

    private static final String OUTPUT_DIR = "test-slips";

    public static void main(String[] args) {
        File dir = new File(OUTPUT_DIR);
        if (!dir.exists()) dir.mkdirs();

        System.out.println("Generating test payment slip images...");

        // Case 1: Valid Normal Payment (Matches ORD-102 & Bank SMS)
        createSlipImage("01_valid_payment_ORD102.png", "Commercial Bank Transfer Receipt", 
                "ORD-102", "8001234567", "BuildStart LK Ltd", "Rs. 25,000.00", "TXN998811", "17/08/2026", false, false);

        // Case 2: Wrong Amount (Order expects 15,000.00, customer pays 10,000.00)
        createSlipImage("02_wrong_amount_ORD101.png", "Sampath Bank Transfer Receipt", 
                "ORD-101", "8001234567", "BuildStart LK Ltd", "Rs. 10,000.00", "TXN100201", "17/08/2026", false, false);

        // Case 3: Wrong Destination Account (Not a business account)
        createSlipImage("03_wrong_account_ORD103.png", "Commercial Bank Transfer Receipt", 
                "ORD-103", "9999888877", "Random Personal Account", "Rs. 5,000.00", "TXN100301", "17/08/2026", false, false);

        // Case 4: Reused Reference (Re-using TXN998811 for a different order ORD-104)
        createSlipImage("04_reused_reference_ORD104.png", "Commercial Bank Transfer Receipt", 
                "ORD-104", "8001234567", "BuildStart LK Ltd", "Rs. 12,500.00", "TXN998811", "17/08/2026", false, false);

        // Case 5: Manipulated / Tampered Slip (Mismatched font & background patch on amount)
        createSlipImage("05_manipulated_tampered_ORD101.png", "Commercial Bank Transfer Receipt", 
                "ORD-101", "8001234567", "BuildStart LK Ltd", "Rs. 15,000.00", "TXN100501", "17/08/2026", true, false);

        // Case 6: Low Quality / Unclear / Blurry Image
        createSlipImage("06_unclear_blurry_slip.png", "Transfer Receipt", 
                "ORD-103", "8001234567", "BuildStart", "Rs. 5,000.00", "TXN???", "17/08/2026", false, true);

        System.out.println("Done! All test images generated in folder: " + dir.getAbsolutePath());
    }

    public static void createSlipImage(String fileName, String bankHeader, String orderRef, 
                                       String toAccount, String accountName, String amount, 
                                       String txnRef, String date, boolean isTampered, boolean isBlurry) {
        int width = 500;
        int height = 650;
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();

        // Anti-aliasing
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Background
        g.setColor(new Color(248, 249, 250));
        g.fillRect(0, 0, width, height);

        // Header Banner
        g.setColor(new Color(15, 23, 42));
        g.fillRect(0, 0, width, 90);

        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 18));
        g.drawString(bankHeader, 30, 40);
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g.drawString("Electronic Funds Transfer Confirmation", 30, 65);

        // Receipt Card Box
        g.setColor(Color.WHITE);
        g.fillRoundRect(25, 110, 450, 500, 15, 15);
        g.setColor(new Color(226, 232, 240));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(25, 110, 450, 500, 15, 15);

        // Receipt Content
        int y = 160;
        g.setColor(new Color(71, 85, 105));
        g.setFont(new Font("SansSerif", Font.PLAIN, 13));

        drawRow(g, "Status:", "COMPLETED / SUCCESS", y, new Color(22, 101, 52), true);
        y += 45;
        drawRow(g, "Date & Time:", date + " 14:22:10", y, Color.BLACK, false);
        y += 45;
        drawRow(g, "To Account:", toAccount, y, Color.BLACK, true);
        y += 45;
        drawRow(g, "Beneficiary:", accountName, y, Color.BLACK, false);
        y += 45;
        drawRow(g, "Order ID:", orderRef, y, Color.BLACK, false);
        y += 45;
        drawRow(g, "Reference No:", txnRef, y, new Color(3, 105, 161), true);
        y += 55;

        // Separator line
        g.setColor(new Color(226, 232, 240));
        g.drawLine(40, y - 15, 460, y - 15);

        // Amount Field
        g.setColor(new Color(71, 85, 105));
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        g.drawString("Amount Transferred:", 45, y + 10);

        if (isTampered) {
            // Visual artifact representing edited slip
            g.setColor(new Color(254, 243, 199));
            g.fillRect(230, y - 15, 210, 35);
            g.setColor(Color.RED);
            g.drawRect(230, y - 15, 210, 35);
            g.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20)); // mismatched font
            g.setColor(Color.DARK_GRAY);
            g.drawString(amount, 245, y + 10);
        } else {
            g.setColor(new Color(15, 23, 42));
            g.setFont(new Font("SansSerif", Font.BOLD, 20));
            g.drawString(amount, 250, y + 10);
        }

        // Footer note
        y += 70;
        g.setColor(new Color(148, 163, 184));
        g.setFont(new Font("SansSerif", Font.ITALIC, 11));
        g.drawString("This is a computer generated receipt. No signature is required.", 45, y);

        // Post-processing blur/noise simulation for unclear test case
        if (isBlurry) {
            image = applyBlurFilter(image);
        }

        g.dispose();

        try {
            ImageIO.write(image, "PNG", new File(OUTPUT_DIR + File.separator + fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void drawRow(Graphics2D g, String label, String value, int y, Color valColor, boolean bold) {
        g.setColor(new Color(100, 116, 139));
        g.setFont(new Font("SansSerif", Font.PLAIN, 13));
        g.drawString(label, 45, y);

        g.setColor(valColor);
        g.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, 13));
        g.drawString(value, 200, y);
    }

    private static BufferedImage applyBlurFilter(BufferedImage src) {
        int w = src.getWidth();
        int h = src.getHeight();
        BufferedImage dest = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        for (int x = 2; x < w - 2; x++) {
            for (int y = 2; y < h - 2; y++) {
                int rgb = src.getRGB(x - (x % 4), y - (y % 4)); // Pixelate & blur effect
                dest.setRGB(x, y, rgb);
            }
        }
        return dest;
    }
}