package com.buildstart.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class PaymentSubmission {
    private int submissionId;
    private String orderId;
    private String imageHash;
    private String imageFilename;
    private BigDecimal extractedAmount;
    private String extractedRef;
    private String extractedAccount;
    private String extractedDate;
    private String decision;
    private String reason;
    private String customerMessage;
    private String suspiciousFlags;
    private String reviewedBy;
    private Timestamp submittedAt;
    
    // Joined details for Admin UI
    private BigDecimal expectedAmount;
    private String customerName;

    public PaymentSubmission() {}

    public int getSubmissionId() { return submissionId; }
    public void setSubmissionId(int submissionId) { this.submissionId = submissionId; }
    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getImageHash() { return imageHash; }
    public void setImageHash(String imageHash) { this.imageHash = imageHash; }
    public String getImageFilename() { return imageFilename; }
    public void setImageFilename(String imageFilename) { this.imageFilename = imageFilename; }
    public BigDecimal getExtractedAmount() { return extractedAmount; }
    public void setExtractedAmount(BigDecimal extractedAmount) { this.extractedAmount = extractedAmount; }
    public String getExtractedRef() { return extractedRef; }
    public void setExtractedRef(String extractedRef) { this.extractedRef = extractedRef; }
    public String getExtractedAccount() { return extractedAccount; }
    public void setExtractedAccount(String extractedAccount) { this.extractedAccount = extractedAccount; }
    public String getExtractedDate() { return extractedDate; }
    public void setExtractedDate(String extractedDate) { this.extractedDate = extractedDate; }
    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public String getCustomerMessage() { return customerMessage; }
    public void setCustomerMessage(String customerMessage) { this.customerMessage = customerMessage; }
    public String getSuspiciousFlags() { return suspiciousFlags; }
    public void setSuspiciousFlags(String suspiciousFlags) { this.suspiciousFlags = suspiciousFlags; }
    public String getReviewedBy() { return reviewedBy; }
    public void setReviewedBy(String reviewedBy) { this.reviewedBy = reviewedBy; }
    public Timestamp getSubmittedAt() { return submittedAt; }
    public void setSubmittedAt(Timestamp submittedAt) { this.submittedAt = submittedAt; }
    public BigDecimal getExpectedAmount() { return expectedAmount; }
    public void setExpectedAmount(BigDecimal expectedAmount) { this.expectedAmount = expectedAmount; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
}