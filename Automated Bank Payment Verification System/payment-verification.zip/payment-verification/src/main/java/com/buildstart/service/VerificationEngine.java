package com.buildstart.service;

import com.buildstart.dao.BankSmsDAO;
import com.buildstart.dao.OrderDAO;
import com.buildstart.dao.PaymentDAO;
import com.buildstart.model.BankSms;
import com.buildstart.model.Order;
import com.buildstart.model.VerificationResult;

import java.math.BigDecimal;
import java.sql.SQLException;

public class VerificationEngine {

    private final OrderDAO orderDAO = new OrderDAO();
    private final PaymentDAO paymentDAO = new PaymentDAO();
    private final BankSmsDAO smsDAO = new BankSmsDAO();

    public VerificationResult evaluatePayment(String orderId, String imageHash, 
                                             OCRService.ExtractedSlipData slipData) throws SQLException {
        VerificationResult result = new VerificationResult();

        // 1. Unclear Image / Illegible Slip Check
        if (slipData == null || !slipData.isLegible || slipData.amount == null) {
            result.setDecision("NEEDS VERIFICATION");
            result.addFlag("UNCLEAR_IMAGE_OR_OCR_FAILED");
            result.setInternalReason("Image is unreadable or missing essential payment figures.");
            result.setCustomerMessage("We couldn't clearly read your payment slip. Please send a clear, complete photograph of the receipt.");
            return result;
        }

        // 2. Duplicate Image Hash Check (Exact Re-upload)
        if (paymentDAO.isImageHashDuplicate(imageHash)) {
            result.setDecision("REJECTED");
            result.addFlag("DUPLICATE_IMAGE_HASH");
            result.setInternalReason("Exact payment image hash has already been submitted in the system.");
            result.setCustomerMessage("This payment slip has already been submitted. Please send a new, valid payment slip.");
            return result;
        }

        // 3. Reused Reference Number Check
        if (slipData.referenceNumber != null && !slipData.referenceNumber.isBlank()) {
            String priorOrder = paymentDAO.findOrderUsingReference(slipData.referenceNumber);
            if (priorOrder != null && !priorOrder.equalsIgnoreCase(orderId)) {
                result.setDecision("REJECTED");
                result.addFlag("REUSED_TRANSACTION_REFERENCE");
                result.setInternalReason("Transaction Reference #" + slipData.referenceNumber + " was already verified for order: " + priorOrder);
                result.setCustomerMessage("This payment appears to have already been used for another order. Please send the correct payment slip.");
                return result;
            }
        }

        // 4. Order Existence & Status Check
        Order order = orderDAO.getOrderById(orderId);
        if (order == null) {
            result.setDecision("REJECTED");
            result.addFlag("INVALID_ORDER_ID");
            result.setInternalReason("No matching order found for ID: " + orderId);
            result.setCustomerMessage("The order ID provided could not be found. Please check your order details.");
            return result;
        }

        if ("PAID".equalsIgnoreCase(order.getOrderStatus())) {
            result.setDecision("REJECTED");
            result.addFlag("ORDER_ALREADY_SETTLED");
            result.setInternalReason("Order " + orderId + " is already marked as PAID.");
            result.setCustomerMessage("This order has already been paid and processed.");
            return result;
        }

        // 5. Amount Matching Check
        if (order.getExpectedAmount().compareTo(slipData.amount) != 0) {
            result.setDecision("REJECTED");
            result.addFlag("AMOUNT_MISMATCH");
            result.setInternalReason(String.format("Amount mismatch: Expected Rs. %.2f, Slip indicates Rs. %.2f", 
                    order.getExpectedAmount(), slipData.amount));
            result.setCustomerMessage(String.format("The payment amount (Rs. %.2f) does not match your order total (Rs. %.2f). Please check and submit the correct slip.",
                    slipData.amount, order.getExpectedAmount()));
            return result;
        }

        // 6. Recipient Bank Account Validation
        if (slipData.targetAccount != null && !slipData.targetAccount.isBlank()) {
            boolean isAccountValid = paymentDAO.isValidBusinessAccount(slipData.targetAccount);
            if (!isAccountValid) {
                result.setDecision("REJECTED");
                result.addFlag("WRONG_RECEIVING_ACCOUNT");
                result.setInternalReason("Recipient account " + slipData.targetAccount + " does not belong to the business.");
                result.setCustomerMessage("The payment was transferred to an unrecognized account. Please check our official bank details.");
                return result;
            }
        }

        // 7. Dual Evidence: Bank SMS Reconciliation
        if (slipData.referenceNumber != null && !slipData.referenceNumber.isBlank()) {
            BankSms matchedSms = smsDAO.findMatchingSms(slipData.amount, slipData.referenceNumber);
            if (matchedSms != null) {
                // SMS matched
                smsDAO.markSmsMatched(matchedSms.getSmsId(), orderId);
                orderDAO.updateOrderStatus(orderId, "PAID");

                result.setDecision("APPROVED");
                result.setInternalReason("Slip details verified and matched with Bank SMS (ID: " + matchedSms.getSmsId() + ").");
                result.setCustomerMessage("Your payment of Rs. " + slipData.amount + " has been verified. Your order is confirmed!");
                return result;
            }
        }

        // 8. Fallback: Slip is valid but SMS not yet received / missing reference
        result.setDecision("NEEDS VERIFICATION");
        result.addFlag("PENDING_SMS_RECONCILIATION");
        result.setInternalReason("Slip is syntactically valid and amounts match, but awaiting bank SMS confirmation.");
        result.setCustomerMessage("Payment slip received. We are waiting for bank confirmation and will confirm your order shortly.");
        return result;
    }
}