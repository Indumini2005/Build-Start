package com.buildstart.dao;

import com.buildstart.model.PaymentSubmission;
import com.buildstart.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    public boolean isImageHashDuplicate(String hash) throws SQLException {
        String sql = "SELECT submission_id FROM payment_submissions WHERE image_hash = ? LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, hash);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public String findOrderUsingReference(String ref) throws SQLException {
        String sql = "SELECT order_id FROM payment_submissions WHERE extracted_ref = ? AND decision = 'APPROVED' LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ref);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("order_id");
                }
            }
        }
        return null;
    }

    public boolean isValidBusinessAccount(String accountNumberPart) throws SQLException {
        String sql = "SELECT account_id FROM business_accounts WHERE account_number LIKE ? LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + accountNumberPart + "%");
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public int saveSubmission(PaymentSubmission sub) throws SQLException {
        String sql = "INSERT INTO payment_submissions (order_id, image_hash, image_filename, extracted_amount, extracted_ref, " +
                     "extracted_account, extracted_date, decision, reason, customer_message, suspicious_flags, reviewed_by) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, sub.getOrderId());
            ps.setString(2, sub.getImageHash());
            ps.setString(3, sub.getImageFilename());
            ps.setBigDecimal(4, sub.getExtractedAmount());
            ps.setString(5, sub.getExtractedRef());
            ps.setString(6, sub.getExtractedAccount());
            ps.setString(7, sub.getExtractedDate());
            ps.setString(8, sub.getDecision());
            ps.setString(9, sub.getReason());
            ps.setString(10, sub.getCustomerMessage());
            ps.setString(11, sub.getSuspiciousFlags());
            ps.setString(12, sub.getReviewedBy() != null ? sub.getReviewedBy() : "SYSTEM");
            ps.executeUpdate();
            
            try (ResultSet gk = ps.getGeneratedKeys()) {
                if (gk.next()) return gk.getInt(1);
            }
        }
        return 0;
    }

    public List<PaymentSubmission> getAllSubmissions() throws SQLException {
        List<PaymentSubmission> list = new ArrayList<>();
        String sql = "SELECT s.*, o.customer_name, o.expected_amount FROM payment_submissions s " +
                     "JOIN orders o ON s.order_id = o.order_id ORDER BY s.submitted_at DESC";
        try (Connection conn = DBUtil.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                PaymentSubmission sub = new PaymentSubmission();
                sub.setSubmissionId(rs.getInt("submission_id"));
                sub.setOrderId(rs.getString("order_id"));
                sub.setImageHash(rs.getString("image_hash"));
                sub.setImageFilename(rs.getString("image_filename"));
                sub.setExtractedAmount(rs.getBigDecimal("extracted_amount"));
                sub.setExtractedRef(rs.getString("extracted_ref"));
                sub.setExtractedAccount(rs.getString("extracted_account"));
                sub.setExtractedDate(rs.getString("extracted_date"));
                sub.setDecision(rs.getString("decision"));
                sub.setReason(rs.getString("reason"));
                sub.setCustomerMessage(rs.getString("customer_message"));
                sub.setSuspiciousFlags(rs.getString("suspicious_flags"));
                sub.setReviewedBy(rs.getString("reviewed_by"));
                sub.setSubmittedAt(rs.getTimestamp("submitted_at"));
                sub.setCustomerName(rs.getString("customer_name"));
                sub.setExpectedAmount(rs.getBigDecimal("expected_amount"));
                list.add(sub);
            }
        }
        return list;
    }

    public void updateDecision(int submissionId, String decision, String reason, String reviewer) throws SQLException {
        String sql = "UPDATE payment_submissions SET decision = ?, reason = ?, reviewed_by = ? WHERE submission_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, decision);
            ps.setString(2, reason);
            ps.setString(3, reviewer);
            ps.setInt(4, submissionId);
            ps.executeUpdate();
        }
    }
}