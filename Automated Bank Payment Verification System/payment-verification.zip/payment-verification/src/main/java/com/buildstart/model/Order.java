package com.buildstart.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class Order {
    private String orderId;
    private String customerName;
    private String customerPhone;
    private BigDecimal expectedAmount;
    private String orderStatus;
    private Timestamp createdAt;

    public Order() {}

    public Order(String orderId, String customerName, String customerPhone, BigDecimal expectedAmount, String orderStatus) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.expectedAmount = expectedAmount;
        this.orderStatus = orderStatus;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public String getCustomerPhone() { return customerPhone; }
    public void setCustomerPhone(String customerPhone) { this.customerPhone = customerPhone; }
    public BigDecimal getExpectedAmount() { return expectedAmount; }
    public void setExpectedAmount(BigDecimal expectedAmount) { this.expectedAmount = expectedAmount; }
    public String getOrderStatus() { return orderStatus; }
    public void setOrderStatus(String orderStatus) { this.orderStatus = orderStatus; }
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}