package com.buildstart.servlet;

import com.buildstart.dao.BankSmsDAO;
import com.buildstart.service.OCRService;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/bank-sms")
public class BankSmsServlet extends HttpServlet {

    private final BankSmsDAO smsDAO = new BankSmsDAO();
    private final OCRService ocrService = new OCRService();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String rawSms = request.getParameter("rawSms");
        if (rawSms == null || rawSms.isBlank()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write("{\"error\":\"rawSms parameter is required.\"}");
            return;
        }

        try {
            // Extract attributes from SMS text
            OCRService.ExtractedSlipData parsed = ocrService.parseSlipText(rawSms);
            smsDAO.saveSms(rawSms, parsed.amount, parsed.referenceNumber, parsed.targetAccount);

            out.write("{\"status\":\"SUCCESS\", \"message\":\"SMS ingested successfully.\"}");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}