package com.buildstart.service;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OCRService {

    public static class ExtractedSlipData {
        public BigDecimal amount;
        public String referenceNumber;
        public String targetAccount;
        public String transactionDate;
        public boolean isLegible = true;
    }

    /**
     * Parses raw extracted text or simulated slip input using regex patterns.
     */
    public ExtractedSlipData parseSlipText(String rawText) {
        ExtractedSlipData data = new ExtractedSlipData();
        if (rawText == null || rawText.trim().length() < 10) {
            data.isLegible = false;
            return data;
        }

        // Amount parsing (Matches Rs. 25,000.00, LKR 25000, 25000.00)
        Pattern amountPattern = Pattern.compile("(?:Rs\\.?|LKR)?\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{2})?)", Pattern.CASE_INSENSITIVE);
        Matcher amountMatcher = amountPattern.matcher(rawText);
        if (amountMatcher.find()) {
            try {
                String clean = amountMatcher.group(1).replace(",", "");
                data.amount = new BigDecimal(clean);
            } catch (Exception ignored) {}
        }

        // Reference parsing (Ref: 123456, TXN-998811, Reference No 998811)
        Pattern refPattern = Pattern.compile("(?:Ref(?:erence)?(?:\\s*(?:No|#)?:?)?\\s*|TXN-?)([A-Z0-9]{5,20})", Pattern.CASE_INSENSITIVE);
        Matcher refMatcher = refPattern.matcher(rawText);
        if (refMatcher.find()) {
            data.referenceNumber = refMatcher.group(1).toUpperCase();
        }

        // Account number parsing (A/C: 8001234567, To Account: 002910005544)
        Pattern accPattern = Pattern.compile("(?:A\\/C|Account(?:\\s*(?:No|#)?:?)?)\\s*([0-9]{8,16})", Pattern.CASE_INSENSITIVE);
        Matcher accMatcher = accPattern.matcher(rawText);
        if (accMatcher.find()) {
            data.targetAccount = accMatcher.group(1);
        }

        // Date parsing (17/08/2026, 2026-08-17)
        Pattern datePattern = Pattern.compile("(\\d{2}[\\/\\-\\.]\\d{2}[\\/\\-\\.]\\d{4}|\\d{4}[\\/\\-\\.]\\d{2}[\\/\\-\\.]\\d{2})");
        Matcher dateMatcher = datePattern.matcher(rawText);
        if (dateMatcher.find()) {
            data.transactionDate = dateMatcher.group(1);
        }

        if (data.amount == null && data.referenceNumber == null) {
            data.isLegible = false;
        }

        return data;
    }
}