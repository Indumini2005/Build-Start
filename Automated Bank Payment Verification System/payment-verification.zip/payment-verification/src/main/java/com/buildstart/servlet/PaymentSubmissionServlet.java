package com.buildstart.servlet;

import com.buildstart.dao.PaymentDAO;
import com.buildstart.model.PaymentSubmission;
import com.buildstart.model.VerificationResult;
import com.buildstart.service.OCRService;
import com.buildstart.service.VerificationEngine;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.UUID;

@WebServlet("/api/submit-payment")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 10 * 1024 * 1024)
public class PaymentSubmissionServlet extends HttpServlet {

    private final OCRService ocrService = new OCRService();
    private final VerificationEngine verificationEngine = new VerificationEngine();
    private final PaymentDAO paymentDAO = new PaymentDAO();
    private final Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String orderId = request.getParameter("orderId");
            String rawText = request.getParameter("rawText"); // OCR extracted / simulated slip text
            Part filePart = request.getPart("slipImage");

            if (orderId == null || filePart == null) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.write("{\"error\": \"orderId and slipImage are required.\"}");
                return;
            }

            // Save file
            String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdirs();

            String submittedFileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
            String storedFileName = System.currentTimeMillis() + "_" + submittedFileName;
            String fullFilePath = uploadPath + File.separator + storedFileName;
            filePart.write(fullFilePath);

            // Compute SHA-256 Hash
            String imageHash = computeHash(fullFilePath);

            // Run OCR / Text Parsing
            OCRService.ExtractedSlipData slipData = ocrService.parseSlipText(rawText);

            // Run Verification Engine
            VerificationResult result = verificationEngine.evaluatePayment(orderId, imageHash, slipData);

            // Persist Submission
            PaymentSubmission submission = new PaymentSubmission();
            submission.setOrderId(orderId);
            submission.setImageHash(imageHash);
            submission.setImageFilename(storedFileName);
            submission.setExtractedAmount(slipData.amount);
            submission.setExtractedRef(slipData.referenceNumber);
            submission.setExtractedAccount(slipData.targetAccount);
            submission.setExtractedDate(slipData.transactionDate);
            submission.setDecision(result.getDecision());
            submission.setReason(result.getInternalReason());
            submission.setCustomerMessage(result.getCustomerMessage());
            submission.setSuspiciousFlags(result.getFlagsAsString());

            int submissionId = paymentDAO.saveSubmission(submission);
            submission.setSubmissionId(submissionId);

            out.write(gson.toJson(submission));

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"error\": \"" + e.getMessage() + "\"}");
            e.printStackTrace();
        }
    }

    private String computeHash(String filePath) {
        try (InputStream is = new FileInputStream(filePath)) {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int read;
            while ((read = is.read(buffer)) > 0) digest.update(buffer, 0, read);
            StringBuilder sb = new StringBuilder();
            for (byte b : digest.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return UUID.randomUUID().toString();
        }
    }
}