package com.buildstart.dao;

import com.buildstart.model.Order;
import com.buildstart.util.DBUtil;

import java.sql.*;

public class OrderDAO {

    public Order getOrderById(String orderId) throws SQLException {
        String sql = "SELECT * FROM orders WHERE order_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Order order = new Order();
                    order.setOrderId(rs.getString("order_id"));
                    order.setCustomerName(rs.getString("customer_name"));
                    order.setCustomerPhone(rs.getString("customer_phone"));
                    order.setExpectedAmount(rs.getBigDecimal("expected_amount"));
                    order.setOrderStatus(rs.getString("order_status"));
                    order.setCreatedAt(rs.getTimestamp("created_at"));
                    return order;
                }
            }
        }
        return null;
    }

    public void updateOrderStatus(String orderId, String status) throws SQLException {
        String sql = "UPDATE orders SET order_status = ? WHERE order_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, orderId);
            ps.executeUpdate();
        }
    }
}