package com.buildstart.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class BankSms {
    private int smsId;
    private String rawMessage;
    private BigDecimal extractedAmount;
    private String extractedRef;
    private String accountLast4;
    private Timestamp smsTimestamp;
    private boolean isMatched;
    private String matchedOrderId;

    public BankSms() {}

    public int getSmsId() { return smsId; }
    public void setSmsId(int smsId) { this.smsId = smsId; }
    public String getRawMessage() { return rawMessage; }
    public void setRawMessage(String rawMessage) { this.rawMessage = rawMessage; }
    public BigDecimal getExtractedAmount() { return extractedAmount; }
    public void setExtractedAmount(BigDecimal extractedAmount) { this.extractedAmount = extractedAmount; }
    public String getExtractedRef() { return extractedRef; }
    public void setExtractedRef(String extractedRef) { this.extractedRef = extractedRef; }
    public String getAccountLast4() { return accountLast4; }
    public void setAccountLast4(String accountLast4) { this.accountLast4 = accountLast4; }
    public Timestamp getSmsTimestamp() { return smsTimestamp; }
    public void setSmsTimestamp(Timestamp smsTimestamp) { this.smsTimestamp = smsTimestamp; }
    public boolean isMatched() { return isMatched; }
    public void setMatched(boolean matched) { isMatched = matched; }
    public String getMatchedOrderId() { return matchedOrderId; }
    public void setMatchedOrderId(String matchedOrderId) { this.matchedOrderId = matchedOrderId; }
}