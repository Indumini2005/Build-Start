package com.buildstart.dao;

import com.buildstart.model.BankSms;
import com.buildstart.util.DBUtil;

import java.math.BigDecimal;
import java.sql.*;

public class BankSmsDAO {

    public void saveSms(String rawMsg, BigDecimal amount, String ref, String acc4) throws SQLException {
        String sql = "INSERT INTO bank_sms (raw_message, extracted_amount, extracted_ref, account_last4) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, rawMsg);
            ps.setBigDecimal(2, amount);
            ps.setString(3, ref);
            ps.setString(4, acc4);
            ps.executeUpdate();
        }
    }

    public BankSms findMatchingSms(BigDecimal amount, String ref) throws SQLException {
        String sql = "SELECT * FROM bank_sms WHERE extracted_amount = ? AND extracted_ref = ? AND is_matched = FALSE LIMIT 1";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setBigDecimal(1, amount);
            ps.setString(2, ref);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    BankSms sms = new BankSms();
                    sms.setSmsId(rs.getInt("sms_id"));
                    sms.setRawMessage(rs.getString("raw_message"));
                    sms.setExtractedAmount(rs.getBigDecimal("extracted_amount"));
                    sms.setExtractedRef(rs.getString("extracted_ref"));
                    sms.setAccountLast4(rs.getString("account_last4"));
                    sms.setMatched(rs.getBoolean("is_matched"));
                    return sms;
                }
            }
        }
        return null;
    }

    public void markSmsMatched(int smsId, String orderId) throws SQLException {
        String sql = "UPDATE bank_sms SET is_matched = TRUE, matched_order_id = ? WHERE sms_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, orderId);
            ps.setInt(2, smsId);
            ps.executeUpdate();
        }
    }
}