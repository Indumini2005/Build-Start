package com.buildstart.model;

import java.util.ArrayList;
import java.util.List;

public class VerificationResult {
    private String decision; // APPROVED, REJECTED, NEEDS VERIFICATION
    private String internalReason;
    private String customerMessage;
    private List<String> suspiciousFlags = new ArrayList<>();

    public VerificationResult() {}

    public VerificationResult(String decision, String internalReason, String customerMessage) {
        this.decision = decision;
        this.internalReason = internalReason;
        this.customerMessage = customerMessage;
    }

    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
    public String getInternalReason() { return internalReason; }
    public void setInternalReason(String internalReason) { this.internalReason = internalReason; }
    public String getCustomerMessage() { return customerMessage; }
    public void setCustomerMessage(String customerMessage) { this.customerMessage = customerMessage; }
    public List<String> getSuspiciousFlags() { return suspiciousFlags; }
    public void addFlag(String flag) { this.suspiciousFlags.add(flag); }
    public String getFlagsAsString() { return String.join(", ", suspiciousFlags); }
}