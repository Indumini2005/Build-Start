package com.buildstart.servlet;

import com.buildstart.dao.OrderDAO;
import com.buildstart.dao.PaymentDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/api/admin/review")
public class ManualReviewServlet extends HttpServlet {

    private final PaymentDAO paymentDAO = new PaymentDAO();
    private final OrderDAO orderDAO = new OrderDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int submissionId = Integer.parseInt(request.getParameter("submissionId"));
        String orderId = request.getParameter("orderId");
        String action = request.getParameter("action"); // APPROVED or REJECTED
        String reason = request.getParameter("reason");
        String reviewer = request.getParameter("reviewer");

        try {
            paymentDAO.updateDecision(submissionId, action, "Manual Review: " + reason, reviewer);
            if ("APPROVED".equalsIgnoreCase(action)) {
                orderDAO.updateOrderStatus(orderId, "PAID");
            }
            response.setContentType("application/json");
            response.getWriter().write("{\"status\":\"SUCCESS\"}");
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }
}