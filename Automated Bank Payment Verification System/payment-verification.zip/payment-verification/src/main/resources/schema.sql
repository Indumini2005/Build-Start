CREATE DATABASE IF NOT EXISTS buildstart_payments;
USE buildstart_payments;

-- Drop tables if they exist for clean initialization
DROP TABLE IF EXISTS payment_submissions;
DROP TABLE IF EXISTS bank_sms;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS business_accounts;

-- 1. Business Bank Accounts
CREATE TABLE business_accounts (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    bank_name VARCHAR(100) NOT NULL,
    account_number VARCHAR(50) NOT NULL UNIQUE,
    account_holder VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Orders Table
CREATE TABLE orders (
    order_id VARCHAR(50) PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    expected_amount DECIMAL(10, 2) NOT NULL,
    order_status ENUM('PENDING', 'PAID', 'CANCELLED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Inbound Bank SMS Table
CREATE TABLE bank_sms (
    sms_id INT PRIMARY KEY AUTO_INCREMENT,
    raw_message TEXT NOT NULL,
    extracted_amount DECIMAL(10, 2) NOT NULL,
    extracted_ref VARCHAR(100),
    account_last4 VARCHAR(10),
    sms_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_matched BOOLEAN DEFAULT FALSE,
    matched_order_id VARCHAR(50)
);

-- 4. Payment Submissions & Audit Log
CREATE TABLE payment_submissions (
    submission_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id VARCHAR(50) NOT NULL,
    image_hash VARCHAR(64) NOT NULL,
    image_filename VARCHAR(255) NOT NULL,
    extracted_amount DECIMAL(10, 2),
    extracted_ref VARCHAR(100),
    extracted_account VARCHAR(50),
    extracted_date VARCHAR(50),
    decision ENUM('APPROVED', 'REJECTED', 'NEEDS VERIFICATION') NOT NULL,
    reason TEXT NOT NULL,
    customer_message TEXT NOT NULL,
    suspicious_flags TEXT,
    reviewed_by VARCHAR(50) DEFAULT 'SYSTEM',
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Seed Data for Testing Challenge Scenarios
INSERT INTO business_accounts (bank_name, account_number, account_holder) VALUES
('Commercial Bank', '8001234567', 'BuildStart LK Ltd'),
('Sampath Bank', '002910005544', 'BuildStart LK Ltd');

INSERT INTO orders (order_id, customer_name, customer_phone, expected_amount, order_status) VALUES
('ORD-101', 'Kasun Perera', '+94771234567', 15000.00, 'PENDING'),
('ORD-102', 'Dilshan Silva', '+94779876543', 25000.00, 'PENDING'),
('ORD-103', 'Anoma Fernando', '+94712348888', 5000.00, 'PENDING'),
('ORD-104', 'Saman Jayasinghe', '+94755554433', 12500.00, 'PENDING');

-- Seed an existing bank SMS ready to pair with ORD-102
INSERT INTO bank_sms (raw_message, extracted_amount, extracted_ref, account_last4) VALUES
('Rs. 25,000.00 credited to A/C XXXX4567. Ref: TXN998811 on 17/08/2026.', 25000.00, 'TXN998811', '4567');