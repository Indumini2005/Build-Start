document.getElementById('paymentForm').addEventListener('submit', async function(e) {
    e.preventDefault();

    const orderId = document.getElementById('orderId').value;
    const fileInput = document.getElementById('slipImage');
    const rawText = document.getElementById('rawText').value;
    const chatBox = document.getElementById('chatBox');

    if (!fileInput.files[0]) {
        alert('Please choose an image.');
        return;
    }

    // Append user message in chat
    const userMsg = document.createElement('div');
    userMsg.className = 'bubble user-bubble';
    userMsg.innerHTML = `<strong>You:</strong><br>[Attached Payment Slip: ${fileInput.files[0].name}]`;
    chatBox.appendChild(userMsg);

    const formData = new FormData();
    formData.append('orderId', orderId);
    formData.append('slipImage', fileInput.files[0]);
    formData.append('rawText', rawText);

    try {
        const res = await fetch('api/submit-payment', { method: 'POST', body: formData });
        const data = await res.json();

        // Append bot response
        const botMsg = document.createElement('div');
        botMsg.className = 'bubble bot-bubble';
        botMsg.innerHTML = `<strong>BuildStart Bot:</strong><br>${data.customerMessage || data.error}`;
        chatBox.appendChild(botMsg);
        chatBox.scrollTop = chatBox.scrollHeight;

    } catch (err) {
        alert('Error submitting payment: ' + err);
    }
});