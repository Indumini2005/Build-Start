async function loadSubmissions() {
    try {
        const res = await fetch('api/admin/submissions');
        const list = await res.json();

        const tbody = document.getElementById('submissionTableBody');
        tbody.innerHTML = '';

        list.forEach(sub => {
            const tr = document.createElement('tr');
            const badgeClass = sub.decision.replace(' ', '_');

            tr.innerHTML = `
                <td><strong>${sub.orderId}</strong></td>
                <td>${sub.customerName || 'N/A'}</td>
                <td>Rs. ${sub.expectedAmount ? sub.expectedAmount.toFixed(2) : '-'}</td>
                <td>Rs. ${sub.extractedAmount ? sub.extractedAmount.toFixed(2) : '-'}</td>
                <td><code>${sub.extractedRef || 'N/A'}</code></td>
                <td><span class="badge badge-${badgeClass}">${sub.decision}</span></td>
                <td>
                    <strong>${sub.reason}</strong><br>
                    <small style="color:#dc2626;">${sub.suspiciousFlags || ''}</small>
                </td>
                <td>
                    ${sub.decision === 'NEEDS VERIFICATION' ? `
                        <button class="btn" style="padding:4px 8px; font-size:12px;" onclick="review(${sub.submissionId}, '${sub.orderId}', 'APPROVED')">Approve</button>
                        <button class="btn btn-danger" style="padding:4px 8px; font-size:12px;" onclick="review(${sub.submissionId}, '${sub.orderId}', 'REJECTED')">Reject</button>
                    ` : `<span style="color:#64748b; font-size:12px;">Resolved by ${sub.reviewedBy}</span>`}
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (e) {
        console.error(e);
    }
}

async function review(submissionId, orderId, action) {
    const reason = prompt(`Enter reason for manual ${action}:`, "Manual employee verification");
    if (!reason) return;

    const params = new URLSearchParams();
    params.append('submissionId', submissionId);
    params.append('orderId', orderId);
    params.append('action', action);
    params.append('reason', reason);
    params.append('reviewer', 'ADMIN_USER');

    await fetch('api/admin/review', { method: 'POST', body: params });
    loadSubmissions();
}

window.onload = loadSubmissions;